import { SolutionHeader } from "@/components/solution-header"
import { ProblemStatement } from "@/components/problem-statement"
import { SolutionTabs } from "@/components/solution-tabs"
import { SolutionActions } from "@/components/solution-actions"

export default function SolutionPage() {
  return (
    <div className="min-h-screen bg-background">
      <SolutionHeader />
      <main className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        <ProblemStatement />
        <SolutionTabs />
        <SolutionActions />
      </main>
    </div>
  )
}
