import { CodeBlock } from "@/components/code-block"
import { ExternalLink } from "lucide-react"
import Link from "next/link"

export function ExplanationSection() {
  return (
    <div className="space-y-8">
      {/* Kod */}
      <div className="rounded-lg border bg-card p-6">
        <CodeBlock />
      </div>

      {/* Jak to działa */}
      <div className="rounded-lg border bg-card p-6">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-2xl">🧠</span>
          <h3 className="text-lg font-semibold text-foreground">Jak to działa?</h3>
        </div>
        <div className="space-y-4 text-muted-foreground leading-relaxed">
          <div className="space-y-2">
            <p className="font-medium text-foreground">Krok 1: Czyszczenie napisu</p>
            <p className="pl-4">
              Funkcja najpierw usuwa wszystkie spacje z napisu używając{" "}
              <code className="bg-muted px-2 py-0.5 rounded font-mono text-sm text-foreground border border-border">
                .replace(" ", "")
              </code>{" "}
              i zamienia wszystkie litery na małe za pomocą{" "}
              <code className="bg-muted px-2 py-0.5 rounded font-mono text-sm text-foreground border border-border">
                .lower()
              </code>
              .
            </p>
            <p className="pl-4 text-sm bg-muted/50 p-3 rounded border border-border">
              Przykład:{" "}
              <code className="bg-muted px-2 py-0.5 rounded font-mono text-sm text-foreground border border-border">
                "Kobyła ma mały bok"
              </code>{" "}
              →{" "}
              <code className="bg-muted px-2 py-0.5 rounded font-mono text-sm text-foreground border border-border">
                "kobyłamamałybok"
              </code>
            </p>
          </div>

          <div className="space-y-2">
            <p className="font-medium text-foreground">Krok 2: Odwracanie napisu</p>
            <p className="pl-4">
              Python używa notacji slice{" "}
              <code className="bg-muted px-2 py-0.5 rounded font-mono text-sm text-foreground border border-border">
                [::-1]
              </code>
              , która tworzy odwróconą kopię napisu. Środkowy element{" "}
              <code className="bg-muted px-2 py-0.5 rounded font-mono text-sm text-foreground border border-border">
                -1
              </code>{" "}
              oznacza "idź od tyłu".
            </p>
          </div>

          <div className="space-y-2">
            <p className="font-medium text-foreground">Krok 3: Porównanie</p>
            <p className="pl-4">
              Funkcja sprawdza, czy oczyszczony napis jest identyczny z jego odwróconą wersją. Jeśli tak, zwraca{" "}
              <code className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 px-2 py-0.5 rounded font-mono text-sm border border-green-200 dark:border-green-800">
                True
              </code>
              , w przeciwnym razie{" "}
              <code className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 px-2 py-0.5 rounded font-mono text-sm border border-red-200 dark:border-red-800">
                False
              </code>
              .
            </p>
          </div>
        </div>
      </div>

      {/* Typowe błędy */}
      <div className="rounded-lg border bg-card p-6">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-2xl">⚠️</span>
          <h3 className="text-lg font-semibold text-foreground">Typowe błędy</h3>
        </div>
        <ul className="space-y-3 text-muted-foreground leading-relaxed">
          <li className="flex gap-3">
            <span className="text-destructive font-bold">•</span>
            <div>
              <p className="font-medium text-foreground">Zapominanie o wielkości liter</p>
              <p className="text-sm">
                "Kajak" nie będzie równe "kajaK". Zawsze normalizuj wielkość liter używając{" "}
                <code className="bg-muted px-2 py-0.5 rounded font-mono text-sm text-foreground border border-border">
                  .lower()
                </code>
                .
              </p>
            </div>
          </li>
          <li className="flex gap-3">
            <span className="text-destructive font-bold">•</span>
            <div>
              <p className="font-medium text-foreground">Ignorowanie spacji i znaków interpunkcyjnych</p>
              <p className="text-sm">"A man a plan a canal Panama" jest palindromem, ale tylko po usunięciu spacji.</p>
            </div>
          </li>
          <li className="flex gap-3">
            <span className="text-destructive font-bold">•</span>
            <div>
              <p className="font-medium text-foreground">Modyfikowanie oryginalnego napisu</p>
              <p className="text-sm">
                Lepiej stworzyć nową zmienną dla oczyszczonego napisu zamiast nadpisywać parametr funkcji.
              </p>
            </div>
          </li>
        </ul>
      </div>

      {/* Inne podejścia */}
      <div className="rounded-lg border bg-card p-6">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-2xl">🔁</span>
          <h3 className="text-lg font-semibold text-foreground">Inne podejścia</h3>
        </div>
        <div className="space-y-4">
          <div className="space-y-2">
            <p className="font-medium text-foreground">1. Rekurencja</p>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Można sprawdzić, czy pierwszy i ostatni znak są takie same, a następnie wywołać funkcję rekurencyjnie dla
              środkowej części napisu.
            </p>
            <div className="bg-muted/50 dark:bg-slate-900/50 rounded-lg p-3 overflow-x-auto mt-2 border border-border">
              <pre className="m-0 p-0 text-foreground font-mono text-xs leading-relaxed">
                {`def czy_palindrom_rek(napis):
    if len(napis) <= 1:
        return True
    if napis[0] != napis[-1]:
        return False
    return czy_palindrom_rek(napis[1:-1])`}
              </pre>
            </div>
          </div>

          <div className="space-y-2">
            <p className="font-medium text-foreground">2. Dwa wskaźniki (two pointers)</p>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Użyj dwóch wskaźników: jednego na początku, drugiego na końcu. Porównuj znaki i przesuwaj wskaźniki do
              środka.
            </p>
            <div className="bg-muted/50 dark:bg-slate-900/50 rounded-lg p-3 overflow-x-auto mt-2 border border-border">
              <pre className="m-0 p-0 text-foreground font-mono text-xs leading-relaxed">
                {`def czy_palindrom_wskazniki(napis):
    lewy, prawy = 0, len(napis) - 1
    while lewy < prawy:
        if napis[lewy] != napis[prawy]:
            return False
        lewy += 1
        prawy -= 1
    return True`}
              </pre>
            </div>
          </div>

          <div className="space-y-2">
            <p className="font-medium text-foreground">3. Odwracanie stringa</p>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Najprostsze podejście używające{" "}
              <code className="bg-muted px-2 py-0.5 rounded font-mono text-xs text-foreground border border-border">
                reversed()
              </code>{" "}
              lub{" "}
              <code className="bg-muted px-2 py-0.5 rounded font-mono text-xs text-foreground border border-border">
                [::-1]
              </code>
              .
            </p>
          </div>
        </div>
      </div>

      {/* Głębiej w temat */}
      <div className="rounded-lg border bg-card p-6">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-2xl">📚</span>
          <h3 className="text-lg font-semibold text-foreground">Głębiej w temat</h3>
        </div>
        <div className="space-y-3">
          <div className="flex items-start gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-colors">
            <ExternalLink className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
            <div>
              <Link href="#" className="font-medium text-foreground hover:text-accent transition-colors">
                Technika dwóch wskaźników (Two Pointers)
              </Link>
              <p className="text-sm text-muted-foreground mt-1">
                Dowiedz się więcej o tym popularnym wzorcu algorytmicznym używanym w wielu problemach z tablicami i
                napisami.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-colors">
            <ExternalLink className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
            <div>
              <Link href="#" className="font-medium text-foreground hover:text-accent transition-colors">
                Złożoność czasowa i pamięciowa
              </Link>
              <p className="text-sm text-muted-foreground mt-1">
                Zrozum, dlaczego niektóre podejścia są bardziej wydajne niż inne i jak analizować złożoność algorytmów.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-colors">
            <ExternalLink className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
            <div>
              <Link href="#" className="font-medium text-foreground hover:text-accent transition-colors">
                String slicing w Pythonie
              </Link>
              <p className="text-sm text-muted-foreground mt-1">
                Poznaj wszystkie możliwości notacji slice w Pythonie i jak efektywnie pracować z napisami.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
