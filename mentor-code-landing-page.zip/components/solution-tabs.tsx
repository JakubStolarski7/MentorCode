"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { CodeBlock } from "@/components/code-block"
import { ExplanationSection } from "@/components/explanation-section"

export function SolutionTabs() {
  const [activeTab, setActiveTab] = useState<"explanation" | "solution">("explanation")

  return (
    <div className="mb-8">
      <div className="flex gap-2 mb-6 border-b">
        <Button
          variant={activeTab === "explanation" ? "default" : "ghost"}
          onClick={() => setActiveTab("explanation")}
          className="rounded-b-none"
        >
          Wyjaśnienie
        </Button>
        <Button
          variant={activeTab === "solution" ? "default" : "ghost"}
          onClick={() => setActiveTab("solution")}
          className="rounded-b-none"
        >
          Rozwiązanie
        </Button>
      </div>

      {activeTab === "explanation" ? (
        <ExplanationSection />
      ) : (
        <div className="rounded-lg border bg-card p-6">
          <CodeBlock />
        </div>
      )}
    </div>
  )
}
